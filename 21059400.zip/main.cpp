//
// <<Wajahat Khan>>
//  <<WKHAN25>>
// U. of Illinois, Chicago
// CS 251: Fall 2019
//
// Project #02: inputs movies and reviews, allowing the user to search
// by movie ID, movie Name, or review ID.  Uses binary search trees for 
// fast search; no other data structures are allowed.
//



#include <iostream>
#include <stdlib.h>
#include <string>
#include <fstream>
#include "bst.h"
using namespace std;

////////////////////// ACCORDING TO PROFESSOR'S REQUIREMENTS //////
struct movieData
{
	int pubyear;
	string name;
	double total_reviews=0;
	double total_stars=0;
	int num5stars;
	int num4stars;
	int num3stars;
	int num2stars;
	int num1stars;
	int id;
};

string trim(const string& str)
{
	size_t first = str.find_first_not_of(" \t\n\r");
	size_t last = str.find_last_not_of(" \t\n\r");

	if (first == string::npos && last == string::npos)  // empty, or all blanks:
		return "";
	else if (first == string::npos)  // no blanks at the start:
		first = 0;                     // 0-based
	else if (last == string::npos)   // no blanks trailing at end:
		last = str.length() - 1;       // 0-based

	return str.substr(first, (last - first + 1));
}


//
// InputMovies
//
// Inputs the data from the "movies" file, which contains N>0 lines, where
// each line contains:
//     id pubYear name

bool loopover(string input)
{

	for (int i = 0; i < input.length(); i++)
	{
		// if input is integer then return true otherwise return false.
		if (isdigit(input[i]) == false)
		{
			return false;

		}

	}
	return true;
}
void InputMovies(string moviesFilename, string reviewFilename)
{
	struct movieData data;
	binarysearchtree<int, movieData>obj;
	binarysearchtree<string, movieData>obj1;

	ifstream moviesFile(moviesFilename);
	int      id, pubYear, reviewid, rating, counttotal=0,count5 = 0,count4= 0 , count3 =0 , count2 = 0, count1=0;
	string   name, input;
	//double sum = 0.0;
	//double avg = 0.0;

	if (!moviesFile.good())
	{
		cout << "**Error: unable to open movies file '" << moviesFilename << "', exiting" << endl;

		return;
	}

	moviesFile >> id;  // get first ID, or set EOF flag if file empty:

	while (!moviesFile.eof())
	{
		// we have more data, so input publication year and movie name:
		moviesFile >> pubYear;
		getline(moviesFile, name);  // movie name fills rest of input line:

		// trim potential whitespace from both ends of movie name:
		name = trim(name);

		
		data.name = name;
		data.pubyear = pubYear;
		data.id = id;
		data.num1stars = 0;
		data.num2stars = 0;
		data.num3stars = 0;
		data.num4stars = 0;
		data.num5stars = 0;
		
		obj.insert(id, data); //inserting by id  ---> need one more insert function that will add stuff for names simply means need one more tree
		obj1.insertbyname(name, data);

		//	cout << "lets check the size: " <<obj.size() << endl;
			//cout << "lets check the size: " << obj.heightprint() << endl;

		moviesFile >> id;  // get next ID, or set EOF flag if no more data:
	}
	obj.inorder();
	obj1.inorder();
	ifstream reviewfile(reviewFilename);
	if (!reviewfile.good())
	{
		cout << "**Error: unable to open movies file '" << moviesFilename << "', exiting" << endl;

		return;
	}
	reviewfile >> reviewid;
	while (!reviewfile.eof())
	{
		// we have more data, so input publication year and movie name:

		//getline(moviesFile, name);  // movie name fills rest of input line:
		//
		// trim potential whitespace from both ends of movie name:
		//name = trim(name);
		reviewfile >> id;

		// debugging:
		reviewfile >> rating;  // get next ID, or set EOF flag if no more data:


		movieData* rdata;
		movieData* rdataname=NULL;
		rdata = NULL;
		//okay so when we have to search for both byname and byid we have to convert our string input to int and pass in the search function
		rdata = obj.search(id);
		rdataname = obj1.search(rdata->name);
		
		
		//inserting by id  ---> need one more insert function that will add stuff for names simply means need one more tree
	
		if (rdata == NULL || rdataname == NULL)
		{
			break;
		}
		else
		{
			if (rating == 5)
			{
				count5++;
				rdata->num5stars += count5;
				rdataname->num5stars += count5;
				rdata->total_stars += rating;
				rdataname->total_stars += rating;
				rdata->total_reviews += count1 + count2 + count3 + count4 + count5;
				rdataname->total_reviews += count1 + count2 + count3 + count4 + count5;
			}
			else if (rating == 4)
			{
				count4++;
				rdata->num4stars += count4;
				rdataname->num4stars += count4;
				rdata->total_stars += rating;
				rdataname->total_stars += rating;
				rdata->total_reviews += count1 + count2 + count3 + count4 + count5;
				rdataname->total_reviews += count1 + count2 + count3 + count4 + count5;
			}
			else if (rating == 3)
			{
				count3++;
				rdata->num3stars += count3;
				rdataname->num3stars += count3;
				rdata->total_stars += rating;
				rdataname->total_stars += rating;
				rdata->total_reviews += count1 + count2 + count3 + count4 + count5;
				rdataname->total_reviews += count1 + count2 + count3 + count4 + count5;
			}
			else if (rating == 2)
			{
				count2++;
				rdata->num2stars += count2;
				rdataname->num2stars += count2;
				rdata->total_stars += rating;
				rdataname->total_stars += rating;
				rdata->total_reviews += count1 + count2 + count3 + count4 + count5;
				rdataname->total_reviews += count1 + count2 + count3 + count4 + count5;
			}
			else
			{
				count1++;
				rdata->num1stars += count1;
				rdataname->num1stars += count1;
				rdata->total_stars += rating;
				rdataname->total_stars += rating;
				rdata->total_reviews += count1+count2+count3+count4+count5;
				rdataname->total_reviews += count1 + count2 + count3 + count4 + count5;
			}
			
			
		}
		//cout << "this is total reviews: " <<count <<endl;
		
		counttotal++;
		reviewfile >> reviewid;
		count1 = 0;
		count2 = 0;
		count3 = 0;
		count4 = 0;
		count5 = 0;


	}
	
	/////////////////////////////////////search part///////////////
// 	cout << "this is what search returned: " << obj.search(key) <<endl;

	movieData* rdata;

	cout << "NUM movies:  " << obj.size() << endl;
	cout << "NUM reviews:  " << counttotal << endl;  //for review sizes will be the sum of all the reviews.
	cout << endl;
	cout << "TREE BY MOVIE ID:  " << obj.size() << " , " << " Height= " << obj.height() << endl;
	cout << "TREE BY MOVIE NAME:  " << obj1.size() << " , " <<" Height= " <<  obj1.height() << endl;



	do
	{
		cout << "Enter a movie id or name (or # to quit)>  ";
		getline(cin, input);
		 
		 bool y = loopover(input);;
		if (input != "#")
		{
			if ( y== true)
			{
				int x = stoi(input);
				rdata = obj.search(x);
			
				if (rdata == NULL)
				{
					cout << "not found" << endl;
				}
				else
				{
					cout << " MOVIE ID: " << input << endl;
					cout << " MOVIE pubyear: " << rdata->pubyear << endl;
					cout << " MOVIE NAME: " << rdata->name << endl;
					cout << " MOVIE Reviews avg : " << double(rdata->total_stars/rdata->total_reviews) << endl;
					cout << " Number of Reviews : " << rdata->total_reviews<< endl;
					cout << " Number of 5 stars : " << rdata->num5stars << endl;
					cout << " Number of 4 stars : " << rdata->num4stars << endl;
					cout << " Number of 3 stars : " << rdata->num3stars << endl;
					cout << " Number of 2 stars : " << rdata->num2stars << endl;
					cout << " Number of 1 stars : " << rdata->num1stars << endl;
				}
			
			}
			else
			{
				rdata = obj1.search(input);
				if (rdata == NULL)
				{
					cout << "not found" << endl;
				}
				else
				{
					
					cout << " MOVIE pubyear: " << rdata->pubyear << endl;
					cout << " MOVIE ID: " << rdata->id<< endl;
					cout << " MOVIE NAME: " << rdata->name << endl;
					cout << " MOVIE Reviews avg : " << double(rdata->total_stars / rdata->total_reviews) << endl;
					cout << " Number of 5 stars : " << rdata->num5stars << endl;
					cout << " Number of 4 stars : " << rdata->num4stars << endl;
					cout << " Number of 3 stars : " << rdata->num3stars << endl;
					cout << " Number of 2 stars : " << rdata->num2stars << endl;
					cout << " Number of 1 stars : " << rdata->num1stars << endl;
				}
			}
		}
		else
		{
			break;
		}

	} while (input != "#");
}

int main()
{
	struct movieData data;
	
//	tree<int, movieData>bstbyid;
	//tree<int, movieData>bstbyname = bstbyid;
	
	string moviesFilename; // = "movies1.txt";
	string reviewsFilename; // = "reviews1.txt";

	cout << "movies file?> ";
	cin >> moviesFilename;

	cout << "reviews file?> ";
	cin >> reviewsFilename;

	string junk;
	getline(cin, junk);  // discard EOL following last input:

	InputMovies(moviesFilename,reviewsFilename);
	
	// done:
	cout << " Memory is Free " << endl;
return 0;
}

