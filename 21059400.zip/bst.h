#pragma once

#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;
template<typename Tkey, typename Tvalue>
class binarysearchtree
{
private:
	struct node
	{
		Tkey key;
		Tvalue value;
		//	node* root = NULL;
		node* left = NULL;
		node* right = NULL;
	};
public:
	node* root=NULL;
	int Size = 0;
	binarysearchtree()
	{

	}

	binarysearchtree(const binarysearchtree &t)
	{
		root = NULL;
		copy(t.root);

	}
	// this is a preorder traversal (IDEA FROM THE PROFESSOR'S NOTES")
	int copy(node *cpy)
	{
		// okay so this function will add all the elements recursively first it complete left side of the tree including subtrees. Moreover, it will first  
		// copy the root and begin copying stuff. and when there's no element on right and left it will go back and check (this work for subtrees).
		if (cpy == NULL)
		{
			return 0;
		}
		if (cpy)
		{
			insert(cpy->key, cpy->value);
			copy(cpy->left);  //go left to the binary tree 
			copy(cpy->right); // go right 
		}
		return 0;
	}
	void destructorhelper(node* curr)
	{
		if (curr)
		{
			destructorhelper(curr->left);
			destructorhelper(curr->right);
			delete curr;
		}
	}
	~binarysearchtree()
	{
		destructorhelper(root);
	}
	int size()
	{
		return Size;
	}
	void insert(Tkey key, Tvalue value)
	{
		node* prev = NULL;
		node* cur = root;

		//
		// 1. Search to see if tree already contains key:
		//
		
	while (cur != nullptr)
		{
       
			if (key == cur->key)  // already in tree
			{
				//	first->pubyear = value;
                
				return;
			}


			if (key < cur->key)  // search left:
			{
				prev = cur;
				cur = cur->left;
			}
			else if (key > cur->key)
			{
				prev = cur;
				cur = cur->right;
			}
		}
		struct node* newnode = new node();

		newnode->key = key;
		newnode->value = value;
		if (prev == NULL)
		{
        
			root = newnode;
			newnode->value = value;
			newnode->left = NULL;
			newnode->right = NULL;
			Size++;
		}
		else
		{
			cur = root;
			while (cur != NULL)
			{
				if (newnode->key < cur->key)
				{
					if (cur->left == NULL)
					{
						cur->left = newnode;
						newnode->value = value;
						cur = NULL;
					}

					else
					{
						cur = cur->left;    //this part keep searching stuff until appropiate value is found.
					}
				}//for the first if condition
				else
				{
					if (newnode->key > cur->key)
					{
						if (cur->right == NULL)
						{
							cur->right = newnode;
							newnode->value = value;
							cur = NULL;

						}
						else
						{
							cur = cur->right;
						}
					}
					newnode->left = NULL;
					newnode->right = NULL;
				}

			}
			Size++;
		}
	}

void insertbyname(Tkey key, Tvalue value)
	{
		node* prev = nullptr;
		node* cur = root;

		//
		// 1. Search to see if tree already contains key:
		//
		while (cur != nullptr)
		{
			if (key == cur->key)  // already in tree
			{
				return;
			}

			if (key < cur->key)  // search left:
			{
				prev = cur;
				cur = cur->left;
			}
			else if (key > cur->key)
			{
				prev = cur;
				cur = cur->right;
			}
		}
		struct node* newnode = new node();

		newnode->key = key;
		newnode->value = value;
		if (prev == NULL)
		{
			root = newnode;
			newnode->value = value;

			newnode->left = NULL;
			newnode->right = NULL;
		}
		else
		{
			cur = root;
			while (cur != NULL)
			{
				if (newnode->key < cur->key)
				{
					if (cur->left == NULL)
					{
						cur->left = newnode;
						newnode->value = value;
						cur = NULL;
					}

					else
					{
						cur = cur->left;    //this part keep searching stuff until appropiate value is found.
					}
				}//for the first if condition
				else
				{
					if (newnode->key > cur->key)
					{
						if (cur->right == NULL)
						{
							cur->right = newnode;
							newnode->value = value;
							cur = NULL;

						}
						else
						{
							cur = cur->right;
						}
					}
					newnode->left = NULL;
					newnode->right = NULL;
				}
			}
			
		}
		Size++;
	}
	int heightprint(node *curr)
	{
   
		if (curr == NULL)
		{
			return -1;
		}
		else
        {
			int left = heightprint(curr->left);
			int right = heightprint(curr->right);

			if (left > right)
			{
				return (left + 1);

			}
			else
			{
				return (right + 1);
			}
        
		}
        //return -1;
	}

	int height()
	{
    int val = heightprint(root);
		if (val != -1)
		{
			//cout << "what is the height again : " << heightprint(root) << endl;
			return heightprint(root);
		}
		
			return -1;
	
	}
	void bstinorder(node *curr)
	{

		if (curr == NULL)
		{
			return;
		}
		//this will go from largest to smallest
		bstinorder(curr->left);
		//cout << "this is the current node: " << curr->key << endl;
		bstinorder(curr->right);

	}
	void inorder()
	{
		//cout << "INORDER";
		bstinorder(root); //giving the input of linked list unsorted and comes out sorted
		cout << endl;
	}

	Tvalue* search(Tkey key)
	{
		node* curr = root;


		while (curr != NULL)
		{
			if (key == curr->key)
			{

				//cout << "this is the current value " << curr->value << endl;

				return &(curr->value);

			}

			else if (key < curr->key)
			{
				curr = curr->left;

			}

			else
			{
				curr = curr->right;

			}
			/**/

			if (curr == NULL)
			{
				return NULL;
			}
		}


		return &(curr->value);
	}
};
